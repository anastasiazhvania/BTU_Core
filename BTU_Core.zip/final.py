from PyQt5 import QtCore, QtGui, QtWidgets
class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(457, 508)
        MainWindow.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 234, 247);")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gpa = QtWidgets.QPushButton(self.centralwidget)
        self.gpa.setGeometry(QtCore.QRect(30, 230, 191, 191))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.gpa.setFont(font)
        self.gpa.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.gpa.setStyleSheet("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"  \n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}")
        self.gpa.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("pixil-frame-0 (2).png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.gpa.setIcon(icon)
        self.gpa.setIconSize(QtCore.QSize(210, 210))
        self.gpa.setObjectName("gpa")
        self.profile = QtWidgets.QPushButton(self.centralwidget)
        self.profile.setGeometry(QtCore.QRect(30, 20, 191, 191))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.profile.setFont(font)
        self.profile.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.profile.setStyleSheet("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"  \n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}")
        self.profile.setText("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("pixil-frame-0 (1).png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.profile.setIcon(icon1)
        self.profile.setIconSize(QtCore.QSize(250, 250))
        self.profile.setObjectName("profile")
        self.game = QtWidgets.QPushButton(self.centralwidget)
        self.game.setGeometry(QtCore.QRect(240, 30, 191, 191))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.game.setFont(font)
        self.game.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.game.setStyleSheet("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"  \n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"")
        self.game.setText("")
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("pixil-frame-0.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.game.setIcon(icon2)
        self.game.setIconSize(QtCore.QSize(210, 210))
        self.game.setObjectName("game")
        self.avg = QtWidgets.QPushButton(self.centralwidget)
        self.avg.setGeometry(QtCore.QRect(240, 230, 191, 191))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.avg.setFont(font)
        self.avg.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.avg.setStyleSheet("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"  \n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}")
        self.avg.setText("")
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap("AVG.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.avg.setIcon(icon3)
        self.avg.setIconSize(QtCore.QSize(210, 210))
        self.avg.setObjectName("avg")
        self.darkmode = QtWidgets.QPushButton(self.centralwidget)
        self.darkmode.setGeometry(QtCore.QRect(344, 430, 91, 23))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        self.darkmode.setFont(font)
        self.darkmode.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.darkmode.setObjectName("darkmode")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 457, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.darkmode.setText(_translate("MainWindow", "dark mode"))

##########################
#dark/light mode

from PyQt5 import QtWidgets
from __main__ import Ui_MainWindow

class MyApp(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)


        self.ui.darkmode.clicked.connect(self.mode)
        self.dark_mode = False

    def mode(self):
        if self.dark_mode:
            self.setStyleSheet("background-color: rgb(255, 234, 247); color: black;")
            self.ui.darkmode.setText("dark mode")
        else:
            self.setStyleSheet("background-color: rgb(62, 53, 61); color: white;")
            self.ui.darkmode.setText("light mode")
        self.dark_mode = not self.dark_mode


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    window = MyApp()
    window.show()
    sys.exit(app.exec_())