from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton

app = QApplication([])

window = QWidget()
window.setWindowTitle("საშუალო ქულის გამოთვლა")
window.resize(500, 300)
window.move(100, 300)

layout = QVBoxLayout()

label = QLabel('შეიყვანეთ ნიშნები (თითო ახალ ხაზზე):')
layout.addWidget(label)

text = QTextEdit()
text.setPlaceholderText('შეიყვანეთ ყოველი ნიშანი ახალ ხაზზე')
layout.addWidget(text)

window.setLayout(layout)

button = QPushButton('გამოთვლა')
layout.addWidget(button)

result_label = QLabel('')
layout.addWidget(result_label)


def calc_avg():
    input_text = text.toPlainText()
    grades = []
    for line in input_text.split('\n'):
        line = line.strip()
        if line:
            grades.append(float(line))

    if grades:
        average = sum(grades) / len(grades)
        result_label.setText(f"საშუალო ქულა: {average:.2f}")
    else:
        result_label.setText("არ არის შეყვანილი მონაცემები.")

button.clicked.connect(calc_avg)

window.show()
app.exec_()
